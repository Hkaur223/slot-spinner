const elements = [];
for (let i = 0; i <= 9; i++) {
  elements[i] = document.querySelector(`#num${i}`);
}

const spinButton = document.getElementById("spinButton");

const spinningAnimation = async (loopNum, elem) => {
  for (let i = 0; i < loopNum; i++) {
    await new Promise((resolve) => {
      setTimeout(() => {
        resolve();
      }, 50);
    });
    elem.textContent = Math.floor(Math.random() * 10);
  }
  elem.style.backgroundColor = "rgb(0, 200, 7)";
};

spinButton.addEventListener("click", async () => {
  await Promise.all(elements.map((elem, i) => spinningAnimation(10 + i * 5, elem)));
  setTimeout(() => {
    elements.forEach((elem) => {
      elem.style.backgroundColor = "rgb(255, 255, 255)";
    });
  }, 1000);
});
