# Slot Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/harmeen-kaur-the-sans/pen/xxNdXYd](https://codepen.io/harmeen-kaur-the-sans/pen/xxNdXYd).

